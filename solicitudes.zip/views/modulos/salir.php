<?php
	session_destroy();
?>
<script type="text/javascript">
	window.location = "ingreso";
</script>';